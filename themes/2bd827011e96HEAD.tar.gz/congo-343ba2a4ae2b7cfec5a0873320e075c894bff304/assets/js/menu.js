/*
    Closes the hamburger menu when a link is clicked.
*/
function close_menu() {
  document.getElementById("menu-controller").checked = false;
}
