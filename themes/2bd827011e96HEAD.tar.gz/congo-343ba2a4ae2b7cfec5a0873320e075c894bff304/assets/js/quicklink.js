window.addEventListener("load", () => {
  quicklink.listen();
});
