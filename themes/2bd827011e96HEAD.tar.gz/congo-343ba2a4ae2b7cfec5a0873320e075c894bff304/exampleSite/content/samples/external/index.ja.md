---
title: "外部記事 - 私がFathom Analyticsに乗り換えた理由"
date: 2019-01-24
externalUrl: "https://jamespanther.com/writings/i-switched-from-google-analytics-to-fathom-analytics/"
summary: "`externalUrl` フロントマターパラメーターは任意のURLにリンクすることができます。この記事は他の記事と同じように見えますが、このウェブサイトの外にある記事にリンクしています。"
showReadingTime: false
_build:
  render: "never"
  list: "local"
---

`externalUrl` フロントマターパラメーターを使用して、このウェブサイトの外の記事にリンクします。

Mediumの投稿や、第三者のウェブサイトでホストしている研究論文へのリンクなどに最適です。
