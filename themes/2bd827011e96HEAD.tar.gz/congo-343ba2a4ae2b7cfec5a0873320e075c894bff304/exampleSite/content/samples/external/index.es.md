---
title: "Artículo externo - ¿Por qué cambié a Fathom Analytics?"
date: 2019-01-24
externalUrl: "https://jamespanther.com/writings/i-switched-from-google-analytics-to-fathom-analytics/"
summary: "El parámetro `externalUrl` se puede vincular a cualquier URL. Este artículo se parece a cualquier otro, pero se vinculará a una publicación que está fuera del proyecto."
showReadingTime: false
_build:
  render: "never"
  list: "local"
---

Esta página utiliza el parámetro `externalUrl` para vincularlo a un artículo fuera de este sitio web.

Es ideal para cosas como enlaces a publicaciones en Medium o para trabajos de investigación que puede haber alojado en sitios web de terceros.
