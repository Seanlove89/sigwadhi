---
title: "Externer Artikel - Why I switched to Fathom Analytics"
date: 2019-01-24
externalUrl: "https://jamespanther.com/writings/i-switched-from-google-analytics-to-fathom-analytics/"
summary: "Der Parameter `externalUrl` im Front Matter kann zu jeder URL verlinken. Der Artikel sieht aus wie jeder andere, aber verlinkt zu einem Post außerhalb des Hugo-Projekts."
showReadingTime: false
_build:
  render: "never"
  list: "local"
---

Diese Seite verwendet den Parameter `externalUrl`, um auf einen Artikel außerhalb dieser Hugo-Website zu verlinken.

Es ist ideal für Dinge wie die Verlinkung zu Beiträgen auf Medium oder zu wissenschaftlichen Arbeiten, die Sie auf Websites von Dritten gehostet haben.
