---
title: "Páginas de ejemplo"
description: "Vea lo que es posible con Congo."

cascade:
  showEdit: false
  showSummary: true
---

{{< lead >}}
Congo da vida a su contenido. :heart_eyes:
{{< /lead >}}

Esta sección contiene ejemplos que muestran cómo Congo representa diferentes tipos de contenido. También puedes ver una página con una [lista de taxonomía]({{< ref "tags" >}}) de ejemplo.

_**Nota al margen:** Esta página es solo una lista estándar de artículos de Congo, y Hugo se ha configurado para generar un tipo de contenido de `ejemplos` y mostrar resúmenes de artículos._

---
