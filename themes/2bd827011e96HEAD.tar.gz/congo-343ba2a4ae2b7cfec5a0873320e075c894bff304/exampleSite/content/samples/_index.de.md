---
title: "Beispiele für Inhalte"
description: "Sieh dir an, was mit Congo möglich ist."

cascade:
  showEdit: false
  showSummary: true
---

{{< lead >}}
Congo erweckt deinen Inhalt zum Leben. :heart_eyes:
{{< /lead >}}

Dieser Abschnitt enthält einige Demoseiten, die zeigen, wie Congo verschiedene Arten von Inhalten wiedergibt. Sie können auch eine Beispielseite für ein [Taxonomieverzeichnis]({{< ref "tags" >}}) sehen.

_**Hinweis:** Diese Seite ist nur eine standardmäßige Congo-Artikelauflistung und Hugo wurde so konfiguriert, dass er einen Inhaltstyp "Beispiele" generiert und Artikelzusammenfassungen anzeigt._

---
