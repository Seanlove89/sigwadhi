---
title: "表情符号 :parachute:"
date: 2019-03-05
description: "表情符号使用教程"
summary: "📖🏞️🧗🏽🐉🧙🏽‍♂️🧚🏽👸"
tags: ["emoji", "sample"]
---

Congo 默认支持在标题、菜单项和文章内容中使用 Emoji。Emoji 可以直接在内容和前置参数中使用简码。

{{< alert >}}
**注意：** 这些图形的渲染取决于浏览器和平台。要样式化 Emoji，您可以使用第三方 Emoji 字体或字体堆栈。
{{< /alert >}}

Congo 自动在整个主题中替换 Emoji，因此您可以在内容和前置参数中使用简码，它们将在构建时转换为相应的符号。

**示例：** `see_no_evil` :see_no_evil:, `hear_no_evil` :hear_no_evil:, `speak_no_evil` :speak_no_evil:。

[Emojipedia](https://emojipedia.org/) 是一个有用的 Emoji 简码参考网站。
