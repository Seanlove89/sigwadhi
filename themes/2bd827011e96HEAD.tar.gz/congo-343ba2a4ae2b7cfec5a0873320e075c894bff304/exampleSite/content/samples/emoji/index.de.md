---
title: "Emoji :parachute:"
date: 2019-03-05
description: "Leitfaden zur Benutzung von Emoji in Congo"
summary: "📖🏞️🧗🏽🐉🧙🏽‍♂️🧚🏽👸"
tags: ["Emoji", "Beispiele"]
---

Congo unterstützt standardmäßig Emoji. Emoji können in Titeln, Menüpunkten und Artikelinhalten verwendet werden.

{{< alert >}}
**Hinweis:** Das Rendering dieser Glyphen hängt vom Browser und von der Plattform ab. Um die Emoji zu gestalten, kannst du entweder eine Emoji-Schriftart eines Drittanbieters oder einen Font Stack verwenden.
{{< /alert >}}

Die Ersetzung von Emoji erfolgt in Congo automatisch, so dass du in deinen Inhalten und im Front Matter Kurzzeichen verwenden können, die zum Zeitpunkt der Erstellung in die entsprechenden Symbole umgewandelt werden.

**Beispiele für Kurzzeichen:** `see_no_evil` :see_no_evil:, `hear_no_evil` :hear_no_evil:, `speak_no_evil` :speak_no_evil:.

[Emojipedia](https://emojipedia.org/) ist eine nützliche Referenz für Emoji-Kurzzeichen.
