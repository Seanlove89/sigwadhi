---
title: "内容样例"
description: "探索Congo的无限可能"

cascade:
  showEdit: false
  showSummary: true
---

{{< lead >}}
Congo让您的内容栩栩如生。 :heart_eyes:
{{< /lead >}}

这个部分包含一些演示页面，展示了Congo 如何呈现不同类型的内容。您还可以查看一个 [分类法列表]({{< ref "tags" >}}) 页面的示例。

_**附注：** 此页面只是一个标准的Congo文章列表，Hugo已经配置生成了一个`samples`内容类型并显示文章摘要。_

---
