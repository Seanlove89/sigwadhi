---
title: Avanzada
---

Esta es la etiqueta avanzada. Al igual que otras páginas de listas en Congo, puede agregar contenido personalizado a los términos taxonómicos individuales y se mostrará en la parte superior de la lista de términos. :rocket:

También puedes usar estas páginas de contenido para definir metadatos de Hugo como títulos y descripciones que se usarán para SEO y otros fines.
