---
title: Tags
---

CongoはHugoのTaxonomiesを完全にサポートしており、どのようなTaxonomiesの設定にも適応します。Taxonomiesのリストは、用語リストの上に表示されるカスタムコンテンツもサポートしています。

この領域は各Taxonomyに説明的なテキストを追加するために使用することができます。このコンセプトをさらに発展させる方法について、以下の[Tags/advanced]({{< ref "advanced" >}})も参照してください。

---
