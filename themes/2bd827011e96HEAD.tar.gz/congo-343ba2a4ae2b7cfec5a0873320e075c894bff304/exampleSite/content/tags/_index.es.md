---
title: Etiquetas
---

Congo tiene soporte total para las taxonomías de Hugo y se adaptará a cualquier configuración de taxonomía. Las listas de taxonomías como esta también admiten contenido personalizado que se muestra encima de la lista de términos.

Esta área podría usarse para agregar texto descriptivo adicional a cada taxonomía. Consulte el ejemplo de [etiquetas avanzadas]({{< ref path="advanced" >}}) a continuación para ver cómo llevar este concepto aún más lejos.

---
